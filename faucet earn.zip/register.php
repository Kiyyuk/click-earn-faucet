<?php
session_start();
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $referral_code = substr(md5(uniqid()), 0, 10);
    $referred_by = $_POST['referred_by'] ?? null;

    // Validate referral code
    if ($referred_by) {
        $referrer_check = $conn->prepare("SELECT id FROM users WHERE referral_code = ?");
        $referrer_check->bind_param("s", $referred_by);
        $referrer_check->execute();
        $referrer_result = $referrer_check->get_result();
        
        if ($referrer_result->num_rows == 0) {
            die("Invalid referral code.");
        }
    }

    // Insert user
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, referral_code, referred_by) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $username, $email, $password, $referral_code, $referred_by);
    
    if ($stmt->execute()) {
        header("Location: login.php?registered=true");
    } else {
        echo "Error: " . $conn->error;
    }
}


    // reCAPTCHA validation
    $recaptcha_secret = "YOUR_RECAPTCHA_SECRET_KEY";
    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$recaptcha_secret&response=" . $_POST['g-recaptcha-response']);
    $responseKeys = json_decode($response, true);
    if (!$responseKeys["success"]) {
        die("reCAPTCHA verification failed!");
    }

    // Insert user
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, referral_code, referred_by) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $username, $email, $password, $referral_code, $referred_by);
    
    if ($stmt->execute()) {
        header("Location: login.php?registered=true");
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<form method="POST">
    Username: <input type="text" name="username" required><br>
    Email: <input type="email" name="email" required><br>
    Password: <input type="password" name="password" required><br>
    Referral Code (Optional): <input type="text" name="referred_by"><br>
    <div class="g-recaptcha" data-sitekey="YOUR_RECAPTCHA_SITE_KEY"></div>
    <button type="submit">Register</button>
</form>
